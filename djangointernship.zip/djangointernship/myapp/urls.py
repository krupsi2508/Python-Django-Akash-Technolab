from django.urls import path
from . import views
urlpatterns = [
     path('',views.homepageview,name="home"),
     path('about',views.aboutpageview,name="about"),
     path('contact',views.contactpageview,name="contact"),
     path('video',views.videopageview,name="video"),
     path('login',views.loginpageview,name="login"),
     path('welcome',views.welcomepageview,name="welcome"),
     path('reg',views.regpageview,name="reg"),
     path('slist',views.studentlist.as_view(),name="slist"),

     
]
