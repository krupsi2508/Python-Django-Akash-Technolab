from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView
from .models import Student
# Create your views here.
def homepageview(request):
    return render(request,'home.html')
def aboutpageview(request):
    return render(request,'about.html')  
def contactpageview(request):
    return render(request,'contact.html') 
def videopageview(request):
    return render(request,'video.html') 
def regpageview(request):
    return render(request,'reg.html')      
def loginpageview(request):
    return render(request,'login.html')     
def welcomepageview(request):
    return render(request,'welcome.html') 
class studentlist(ListView):
    model = Student
    template_name = 'slist.html'
            
    